# AI Operations Command Center
## Run
Backend:
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```
Demo flow: Detect → Investigate → Decide → Human Approval → Act → Verify.
